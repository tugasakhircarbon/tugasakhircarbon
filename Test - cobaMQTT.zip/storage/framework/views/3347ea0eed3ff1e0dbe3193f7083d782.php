<div class="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
    <div class="flex items-center justify-between">
        <div>
            <p class="text-gray-500"><?php echo e($title); ?></p>
            <h3 class="text-2xl font-bold text-dark">
                <?php echo e($value); ?>

                <?php if(isset($unit)): ?>
                    <span class="text-sm font-normal"><?php echo e($unit); ?></span>
                <?php endif; ?>
            </h3>
        </div>
<div class="p-3 w-12 h-12 rounded-full <?php echo e($iconBgClass); ?> <?php echo e($iconTextClass); ?> flex items-center justify-center">
    <i class="<?php echo e($iconClass); ?> text-xl"></i>
</div>
    </div>
    <?php if(isset($change)): ?>
    <div class="mt-4">
        <span class="<?php echo e($changeClass); ?> text-sm font-medium">
            <i class="<?php echo e($changeIcon); ?>"></i> <?php echo e($change); ?>

        </span>
    </div>
    <?php endif; ?>
</div>
</create_file>
<?php /**PATH D:\CarbonDevelopment\Test - cobaMQTT\resources\views/components/stats-card.blade.php ENDPATH**/ ?>