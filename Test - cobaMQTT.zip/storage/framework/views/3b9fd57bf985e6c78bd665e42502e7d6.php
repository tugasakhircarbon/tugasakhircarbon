

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
    <h2 class="text-2xl font-semibold mb-6 text-primary">Beli Kuota Karbon</h2>

    <?php if($isAdmin): ?>
        <!-- Admin View: Detail with Purchase Info -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div class="bg-green-50 rounded-lg p-4 border border-green-200">
                <h3 class="text-lg font-semibold mb-3">Detail Kuota Karbon</h3>
                <div class="border-t pt-3 mt-3">
                    <div class="grid grid-cols-2 gap-3 text-sm">
                        <div>
                            <div class="text-gray-600">Jumlah Dibeli</div>
                            <div class="text-blue-600 font-semibold text-lg"><?php echo e(number_format($carbonCredit->quantity_to_sell, 2)); ?> kg CO₂e</div>
                        </div>
                        <div>
                            <div class="text-gray-600">Harga per Unit</div>
                            <div class="text-green-600 font-semibold text-lg">Rp <?php echo e(number_format($carbonCredit->price_per_unit, 0, ',', '.')); ?></div>
                        </div>
                    </div>
                    <div class="mt-3 p-3 bg-blue-100 rounded">
                        <div class="text-gray-700 text-sm">Total Pembayaran</div>
                        <div class="text-red-600 font-bold text-xl">Rp <?php echo e(number_format($carbonCredit->quantity_to_sell * $carbonCredit->price_per_unit, 0, ',', '.')); ?></div>
                    </div>
                </div>
            </div>

            <div class="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <h3 class="text-lg font-semibold mb-3">Informasi Penjual</h3>
                <p class="text-gray-700 mb-1"><strong>Nama:</strong> <?php echo e($carbonCredit->owner->name); ?></p>
                <p class="text-gray-700 mb-1"><strong>Email:</strong> <?php echo e($carbonCredit->owner->email); ?></p>
                <p class="text-gray-700 mb-4"><strong>Bergabung:</strong> <?php echo e($carbonCredit->owner->created_at->format('d M Y')); ?></p>
                <div class="mb-4">
                    <span class="inline-flex items-center px-3 py-1 rounded-full bg-green-100 text-green-800 text-sm font-medium">
                        <i class="fas fa-check-circle mr-1" aria-hidden="true"></i> Terverifikasi
                    </span>
                </div>
                <div class="border-t pt-3 mt-3">
                    <div class="bg-yellow-100 p-3 rounded border border-yellow-300">
                        <p class="text-yellow-800 text-sm">
                            <i class="fas fa-info-circle mr-1" aria-hidden="true"></i>
                            <strong>Catatan Admin:</strong> Anda akan secara otomatis membeli seluruh kuota karbon yang tersedia untuk dijual.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <form action="<?php echo e(route('transactions.store', $carbonCredit->id)); ?>" method="POST" id="purchaseForm">
            <?php echo csrf_field(); ?>
            <div class="flex justify-end space-x-4">
                <a href="<?php echo e(route('admin.marketplace')); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-primary">
                    <i class="fas fa-arrow-left mr-2" aria-hidden="true"></i> Kembali
                </a>
                <button type="submit" class="inline-flex items-center px-6 py-3 bg-yellow-500 text-white rounded hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-600 text-lg font-semibold">
                    <i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Lanjut ke Pembayaran
                </button>
            </div>
        </form>
    <?php else: ?>
        <!-- Regular User View: Original Layout -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div class="bg-green-50 rounded-lg p-4 border border-green-200">
                <h3 class="text-lg font-semibold mb-3">Detail Kuota Karbon</h3>
                <h4 class="text-xl font-bold mb-2"><?php echo e($carbonCredit->project_name); ?></h4>
                <p class="text-gray-700 mb-1"><strong>Jenis:</strong> <?php echo e($carbonCredit->type); ?></p>
                <p class="text-gray-700 mb-1"><strong>Lokasi:</strong> <?php echo e($carbonCredit->location); ?></p>
                <p class="text-gray-700 mb-1"><strong>Tahun:</strong> <?php echo e($carbonCredit->year); ?></p>
                <p class="text-gray-700 mb-4"><strong>Sertifikat:</strong> <?php echo e($carbonCredit->certification_standard); ?></p>
                <div class="flex justify-between text-sm text-gray-600">
                    <div>
                        <div>Harga per Unit</div>
                        <div class="text-green-600 font-semibold text-lg">Rp <?php echo e(number_format($carbonCredit->price_per_unit, 0, ',', '.')); ?></div>
                    </div>
                    <div>
                        <div>Tersedia</div>
                        <div class="text-blue-600 font-semibold text-lg"><?php echo e(number_format($carbonCredit->quantity_to_sell, 2)); ?> kg CO₂e</div>
                    </div>
                </div>
            </div>

            <div class="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <h3 class="text-lg font-semibold mb-3">Informasi Penjual</h3>
                <p class="text-gray-700 mb-1"><strong>Nama:</strong> <?php echo e($carbonCredit->owner->name); ?></p>
                <p class="text-gray-700 mb-1"><strong>Email:</strong> <?php echo e($carbonCredit->owner->email); ?></p>
                <p class="text-gray-700 mb-4"><strong>Bergabung:</strong> <?php echo e($carbonCredit->owner->created_at->format('d M Y')); ?></p>
                <div>
                    <span class="inline-flex items-center px-3 py-1 rounded-full bg-green-100 text-green-800 text-sm font-medium">
                        <i class="fas fa-check-circle mr-1" aria-hidden="true"></i> Terverifikasi
                    </span>
                </div>
            </div>
        </div>

        <form action="<?php echo e(route('transactions.store', $carbonCredit->id)); ?>" method="POST" id="purchaseForm" novalidate>
            <?php echo csrf_field(); ?>

            <div class="bg-yellow-50 rounded-lg p-4 border border-yellow-300">
                <h3 class="text-lg font-semibold mb-4 flex items-center space-x-2 text-yellow-700">
                    <i class="fas fa-calculator" aria-hidden="true"></i>
                    <span>Form Pembelian</span>
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="quantity_to_sell" class="block font-semibold mb-1">
                            Jumlah yang ingin dibeli (kg CO₂e)
                        </label>
                        <input type="number" 
                               class="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500 <?php $__errorArgs = ['quantity_to_sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="quantity_to_sell" 
                               name="quantity_to_sell" 
                               step="0.01" 
                               min="0.01" 
                               max="<?php echo e($carbonCredit->quantity_to_sell); ?>" 
                               value="<?php echo e(old('quantity_to_sell')); ?>"
                               placeholder="Masukkan jumlah..."
                               required
                               aria-describedby="quantityHelp"
                               aria-invalid="<?php $__errorArgs = ['quantity_to_sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <p id="quantityHelp" class="text-sm text-gray-600 mt-1">
                            Maksimal: <?php echo e(number_format($carbonCredit->quantity_to_sell, 2)); ?> kg CO₂e
                        </p>
                        <?php $__errorArgs = ['quantity_to_sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-sm mt-1" role="alert"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div>
                        <label class="block font-semibold mb-1" for="totalPrice">
                            Total Harga
                        </label>
                        <div class="flex items-center border border-gray-300 rounded px-3 py-2 bg-white">
                            <span class="text-gray-700 mr-2">Rp</span>
                            <input type="text" class="w-full bg-transparent focus:outline-none" id="totalPrice" readonly value="0" aria-live="polite" />
                        </div>
                        <p class="text-sm text-green-600 mt-1">Harga akan dihitung otomatis</p>
                    </div>
                </div>

                <div id="purchaseSummary" class="mt-4 p-4 bg-blue-100 rounded text-blue-800 hidden" role="region" aria-live="polite" aria-atomic="true">
                    <h4 class="font-semibold mb-2 flex items-center space-x-2">
                        <i class="fas fa-info-circle" aria-hidden="true"></i>
                        <span>Ringkasan Pembelian:</span>
                    </h4>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div><strong>Jumlah:</strong> <span id="summaryAmount">0</span> kg CO₂e</div>
                        <div><strong>Harga per Unit:</strong> Rp <?php echo e(number_format($carbonCredit->price_per_unit, 0, ',', '.')); ?></div>
                        <div><strong>Total:</strong> Rp <span id="summaryTotal">0</span></div>
                    </div>
                </div>

                <div class="flex justify-end space-x-4 mt-6">
                    <a href="<?php echo e(route('marketplace')); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-primary">
                        <i class="fas fa-arrow-left mr-2" aria-hidden="true"></i> Kembali
                    </a>
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-600 disabled:opacity-50 disabled:cursor-not-allowed" id="buyButton" disabled>
                        <i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Lanjut ke Pembayaran
                    </button>
                </div>
            </div>
        </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const isAdmin = <?php echo e($isAdmin ? 'true' : 'false'); ?>;
    
    // Only run calculation logic for regular users
    if (!isAdmin) {
        const amountInput = document.getElementById('quantity_to_sell');
        const totalPriceInput = document.getElementById('totalPrice');
        const buyButton = document.getElementById('buyButton');
        const purchaseSummary = document.getElementById('purchaseSummary');
        const summaryAmount = document.getElementById('summaryAmount');
        const summaryTotal = document.getElementById('summaryTotal');
        
        const pricePerUnit = <?php echo e($carbonCredit->price_per_unit); ?>;
        const maxAmount = <?php echo e($carbonCredit->quantity_to_sell); ?>;

        function calculateTotal() {
            const amount = parseFloat(amountInput.value) || 0;
            const total = amount * pricePerUnit;
            
            // Update total price
            totalPriceInput.value = total.toLocaleString('id-ID');
            
            // Update summary
            if (amount > 0) {
                summaryAmount.textContent = amount.toFixed(2);
                summaryTotal.textContent = total.toLocaleString('id-ID');
                purchaseSummary.classList.remove('hidden');
                buyButton.disabled = false;
            } else {
                purchaseSummary.classList.add('hidden');
                buyButton.disabled = true;
            }
            
            // Validate amount
            if (amount > maxAmount) {
                amountInput.classList.add('is-invalid');
                buyButton.disabled = true;
            } else {
                amountInput.classList.remove('is-invalid');
            }
        }

        amountInput.addEventListener('input', calculateTotal);
        amountInput.addEventListener('change', calculateTotal);
        
        // Initial calculation
        calculateTotal();
    }
    // For admin users, the button is already enabled and no calculation is needed
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CarbonDevelopment\Test - cobaMQTT\resources\views/transactions/create.blade.php ENDPATH**/ ?>