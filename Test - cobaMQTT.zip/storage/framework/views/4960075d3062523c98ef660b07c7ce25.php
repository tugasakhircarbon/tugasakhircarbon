

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
    <h2 class="text-2xl font-semibold mb-6 flex items-center space-x-3 text-primary">
        <i class="fas fa-shopping-cart" aria-hidden="true"></i>
        <span>Beli Kuota Karbon</span>
    </h2>

    <!-- Detail Kuota Karbon -->
    

    <!-- Form Pembelian -->
    <form action="<?php echo e(route('transactions.store', $carbonCredit->id)); ?>" method="POST" id="purchaseForm" class="space-y-6" aria-label="Form Pembelian Kuota Karbon">
        <?php echo csrf_field(); ?>
        <div class="border border-yellow-400 rounded-lg p-4 bg-yellow-50">
            <h3 class="text-lg font-semibold mb-4 flex items-center space-x-2 text-yellow-700">
                <i class="fas fa-calculator" aria-hidden="true"></i>
                <span>Form Pembelian</span>
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="quantity_to_sell" class="block font-semibold mb-1">
                        Jumlah yang ingin dibeli (kg CO₂e)
                    </label>
                    <input type="number"
                           id="quantity_to_sell"
                           name="quantity_to_sell"
                           step="0.01"
                           min="0.01"
                           max="<?php echo e($carbonCredit->quantity_to_sell); ?>"
                           value="<?php echo e(old('quantity_to_sell')); ?>"
                           placeholder="Masukkan jumlah..."
                           required
                           class="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary <?php $__errorArgs = ['quantity_to_sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           aria-describedby="quantityHelp"
                           aria-invalid="<?php $__errorArgs = ['quantity_to_sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                    <p id="quantityHelp" class="text-sm text-gray-600 mt-1">
                        Maksimal: <?php echo e(number_format($carbonCredit->quantity_to_sell, 2)); ?> kg CO₂e
                    </p>
                    <?php $__errorArgs = ['quantity_to_sell'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-sm mt-1" role="alert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="vehicle_id" class="block font-semibold mb-1">Pilih Kendaraan</label>
                    <select id="vehicle_id" name="vehicle_id" required class="w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary <?php $__errorArgs = ['vehicle_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-invalid="<?php $__errorArgs = ['vehicle_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> true <?php else: ?> false <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="" disabled selected>Pilih kendaraan...</option>
                        <?php $__currentLoopData = Auth::user()->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($vehicle->id); ?>" <?php echo e(old('vehicle_id') == $vehicle->id ? 'selected' : ''); ?>>
                                <?php echo e($vehicle->nrkb); ?> - <?php echo e($vehicle->nomor_rangka_5digit); ?> (<?php echo e(ucfirst($vehicle->vehicle_type)); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['vehicle_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-sm mt-1" role="alert"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block font-semibold mb-1" for="totalPrice">Total Harga</label>
                    <div class="flex items-center border border-gray-300 rounded px-3 py-2 bg-white">
                        <span class="text-gray-700 mr-2">Rp</span>
                        <input type="text" id="totalPrice" readonly value="0" class="w-full bg-transparent focus:outline-none" aria-live="polite" />
                    </div>
                    <p class="text-sm text-green-600 mt-1">Harga akan dihitung otomatis</p>
                </div>
            </div>

            <!-- Ringkasan Pembelian -->
            <div id="purchaseSummary" class="mt-4 p-4 bg-blue-100 rounded text-blue-800 hidden" role="region" aria-live="polite" aria-atomic="true">
                <h4 class="font-semibold mb-2 flex items-center space-x-2">
                    <i class="fas fa-info-circle" aria-hidden="true"></i>
                    <span>Ringkasan Pembelian:</span>
                </h4>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div><strong>Jumlah:</strong> <span id="summaryAmount">0</span> kg CO₂e</div>
                    <div><strong>Harga per Unit:</strong> Rp <?php echo e(number_format($carbonCredit->price_per_unit, 0, ',', '.')); ?></div>
                    <div><strong>Total:</strong> Rp <span id="summaryTotal">0</span></div>
                </div>
            </div>

            <div class="flex justify-end space-x-4 mt-6">
                <a href="<?php echo e(route('dashboard')); ?>" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-primary">
                    <i class="fas fa-arrow-left mr-2" aria-hidden="true"></i> Kembali
                </a>
                <button type="submit" id="buyButton" disabled class="inline-flex items-center px-4 py-2 bg-primary text-white rounded hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-green-600">
                    <i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Lanjut ke Pembayaran
                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const amountInput = document.getElementById('quantity_to_sell');
    const totalPriceInput = document.getElementById('totalPrice');
    const buyButton = document.getElementById('buyButton');
    const purchaseSummary = document.getElementById('purchaseSummary');
    const summaryAmount = document.getElementById('summaryAmount');
    const summaryTotal = document.getElementById('summaryTotal');
    
    const pricePerUnit = <?php echo e($carbonCredit->price_per_unit); ?>;
    const maxAmount = <?php echo e($carbonCredit->quantity_to_sell); ?>;

    function calculateTotal() {
        const amount = parseFloat(amountInput.value) || 0;
        const total = amount * pricePerUnit;
        
        // Update total price
        totalPriceInput.value = total.toLocaleString('id-ID');
        
        // Update summary
        if (amount > 0) {
            summaryAmount.textContent = amount.toFixed(2);
            summaryTotal.textContent = total.toLocaleString('id-ID');
            purchaseSummary.classList.remove('hidden');
            buyButton.disabled = false;
        } else {
            purchaseSummary.classList.add('hidden');
            buyButton.disabled = true;
        }
        
        // Validate amount
        if (amount > maxAmount) {
            amountInput.classList.add('border-red-500');
            buyButton.disabled = true;
        } else {
            amountInput.classList.remove('border-red-500');
        }
    }

    amountInput.addEventListener('input', calculateTotal);
    amountInput.addEventListener('change', calculateTotal);
    
    // Initial calculation
    calculateTotal();
});
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CarbonDevelopment\Test - cobaMQTT\resources\views/marketplace/index.blade.php ENDPATH**/ ?>