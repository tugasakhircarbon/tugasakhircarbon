

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto p-6">
    <?php if(Auth::user()->role == 'admin'): ?>
        <h1 class="text-2xl font-bold mb-4">Manajemen Payout Admin</h1>
    <?php else: ?>
        <h1 class="text-2xl font-bold mb-4">Payout Saya</h1>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-300 rounded-lg" role="table" aria-label="Daftar Payout">
            <thead>
                <tr>
                    <th scope="col" class="py-2 px-4 border-b text-left text-sm font-semibold uppercase">ID Payout</th>
                    <?php if(Auth::user()->role == 'admin'): ?>
                    <th scope="col" class="py-2 px-4 border-b text-left text-sm font-semibold uppercase">User</th>
                    <?php endif; ?>
                    <th scope="col" class="py-2 px-4 border-b text-left text-sm font-semibold uppercase">Jumlah</th>
                    <th scope="col" class="py-2 px-4 border-b text-left text-sm font-semibold uppercase">Status</th>
                    <th scope="col" class="py-2 px-4 border-b text-left text-sm font-semibold uppercase">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 focus-within:bg-gray-100 transition-colors duration-200" tabindex="0">
                    <td class="py-2 px-4 border-b"><?php echo e($payout->payout_id); ?></td>
                    <?php if(Auth::user()->role == 'admin'): ?>
                    <td class="py-2 px-4 border-b"><?php echo e($payout->user->name ?? 'N/A'); ?></td>
                    <?php endif; ?>
                    <td class="py-2 px-4 border-b">Rp <?php echo e(number_format($payout->net_amount, 2, ',', '.')); ?></td>
                    <td class="py-2 px-4 border-b capitalize">
                        <?php
                            $statusColors = [
                                'pending' => 'bg-yellow-100 text-yellow-800',
                                'created' => 'bg-blue-100 text-blue-800',
                                'approved' => 'bg-green-100 text-green-800',
                                'rejected' => 'bg-red-100 text-red-800',
                            ];
                            $colorClass = $statusColors[$payout->status] ?? 'bg-gray-200 text-gray-700';
                        ?>
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold <?php echo e($colorClass); ?>"><?php echo e(ucfirst($payout->status)); ?></span>
                    </td>
                    <td class="py-2 px-4 border-b space-x-2">
                        <?php if($payout->status === 'pending'): ?>
                        <form action="<?php echo e(route('payouts.create', $payout->id)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="inline-flex items-center px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-600" aria-label="Buat payout <?php echo e($payout->payout_id); ?>">
                                <i class="fas fa-plus mr-1" aria-hidden="true"></i> Buat
                            </button>
                        </form>
                        <?php else: ?>
                        <span class="text-gray-500">Tidak ada aksi</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($payouts->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CarbonDevelopment\Test - cobaMQTT\resources\views/payouts/index.blade.php ENDPATH**/ ?>