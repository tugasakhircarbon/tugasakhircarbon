<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto p-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold flex items-center space-x-3 text-primary">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </h1>
        <div class="flex items-center space-x-4">
            <a href="<?php echo e(route('emission.monitoring')); ?>" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2">
                <i class="fas fa-chart-line"></i>
                <span>Monitoring Emisi</span>
            </a>
            <div class="text-gray-600">
                Selamat datang, <?php echo e(Auth::user()->name); ?>!
                <?php if(Auth::user()->isAdmin()): ?>
                    <span class="inline-block bg-yellow-400 text-yellow-900 text-xs font-semibold px-2 py-1 rounded ml-2">Administrator</span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Emission Monitoring Summary -->
    <?php if(isset($emissionStats) && $emissionStats['total_devices'] > 0): ?>
    <div class="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-xl shadow border border-green-100 mb-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-800 flex items-center space-x-2">
                <i class="fas fa-leaf text-green-600"></i>
                <span>Monitoring Emisi Real-time</span>
            </h3>
            <div class="flex items-center space-x-2">
                <div class="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span class="text-sm text-gray-600">Live Data</span>
            </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div class="bg-white p-4 rounded-lg shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Total Kendaraan</p>
                        <p class="text-2xl font-bold text-gray-800"><?php echo e($emissionStats['total_devices']); ?></p>
                    </div>
                    <i class="fas fa-car text-blue-500 text-xl"></i>
                </div>
            </div>
            
            <div class="bg-white p-4 rounded-lg shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Sensor Aktif</p>
                        <p class="text-2xl font-bold text-green-600"><?php echo e($emissionStats['active_devices']); ?></p>
                    </div>
                    <i class="fas fa-wifi text-green-500 text-xl"></i>
                </div>
            </div>
            
            <div class="bg-white p-4 rounded-lg shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Emisi Hari Ini</p>
                        <p class="text-2xl font-bold text-orange-600"><?php echo e(number_format($emissionStats['today_emissions'], 2)); ?> kg</p>
                    </div>
                    <i class="fas fa-smog text-orange-500 text-xl"></i>
                </div>
            </div>
            
            <div class="bg-white p-4 rounded-lg shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Alert Aktif</p>
                        <p class="text-2xl font-bold <?php echo e($emissionStats['alerts_count'] > 0 ? 'text-red-600' : 'text-green-600'); ?>">
                            <?php echo e($emissionStats['alerts_count']); ?>

                        </p>
                    </div>
                    <i class="fas fa-exclamation-triangle <?php echo e($emissionStats['alerts_count'] > 0 ? 'text-red-500' : 'text-green-500'); ?> text-xl"></i>
                </div>
            </div>
        </div>

        <?php if(count($emissionStats['vehicles']) > 0): ?>
        <div class="bg-white p-4 rounded-lg shadow-sm">
            <h4 class="font-semibold text-gray-800 mb-3">Status Kendaraan</h4>
            <div class="space-y-2">
                <?php $__currentLoopData = $emissionStats['vehicles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center space-x-3">
                        <i class="fas <?php echo e($vehicle['vehicle_type'] === 'motorcycle' ? 'fa-motorcycle' : 'fa-car'); ?> text-blue-500"></i>
                        <div>
                            <p class="font-medium text-gray-800"><?php echo e($vehicle['nrkb']); ?></p>
                            <p class="text-sm text-gray-600"><?php echo e(ucfirst($vehicle['vehicle_type'])); ?></p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <div class="text-center">
                            <p class="text-xs text-gray-500">CO2e PPM</p>
                            
                        </div>
                        <div class="text-center">
                            <p class="text-xs text-gray-500">Emisi Harian</p>
                            <p class="font-semibold text-orange-600"><?php echo e(number_format($vehicle['daily_emissions_kg'], 2)); ?> kg</p>
                        </div>
                        <div class="flex items-center space-x-2">
                            <div class="w-3 h-3 rounded-full <?php echo e($vehicle['sensor_status'] === 'active' ? 'bg-green-500' : ($vehicle['sensor_status'] === 'error' ? 'bg-red-500' : 'bg-gray-400')); ?>"></div>
                            <span class="text-sm capitalize <?php echo e($vehicle['sensor_status'] === 'active' ? 'text-green-600' : ($vehicle['sensor_status'] === 'error' ? 'text-red-600' : 'text-gray-600')); ?>">
                                <?php echo e($vehicle['sensor_status']); ?>

                            </span>
                            <?php if($vehicle['has_alert']): ?>
                                <i class="fas fa-exclamation-triangle text-red-500 text-sm"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Statistik Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <?php if (isset($component)) { $__componentOriginal8f216e051c231b98198765acd723fb77 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f216e051c231b98198765acd723fb77 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stats-card','data' => ['title' => 'Pencairan Tertunda','value' => $stats['pending_payouts'],'iconClass' => 'fas fa-clock','iconBgClass' => 'bg-yellow-100','iconTextClass' => 'text-yellow-500']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stats-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pencairan Tertunda','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stats['pending_payouts']),'icon-class' => 'fas fa-clock','icon-bg-class' => 'bg-yellow-100','icon-text-class' => 'text-yellow-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f216e051c231b98198765acd723fb77)): ?>
<?php $attributes = $__attributesOriginal8f216e051c231b98198765acd723fb77; ?>
<?php unset($__attributesOriginal8f216e051c231b98198765acd723fb77); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f216e051c231b98198765acd723fb77)): ?>
<?php $component = $__componentOriginal8f216e051c231b98198765acd723fb77; ?>
<?php unset($__componentOriginal8f216e051c231b98198765acd723fb77); ?>
<?php endif; ?>
        <?php $__currentLoopData = $vehicleCarbonCredits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal8f216e051c231b98198765acd723fb77 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f216e051c231b98198765acd723fb77 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stats-card','data' => ['title' => $vehicle['nrkb'],'value' => number_format($vehicle['effective_quota'], 2) . ' kg','iconClass' => $vehicle['vehicle_type'] === 'motorcycle' ? 'fas fa-motorcycle' : 'fas fa-car','iconBgClass' => 'bg-blue-100','iconTextClass' => 'text-blue-500']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stats-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vehicle['nrkb']),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($vehicle['effective_quota'], 2) . ' kg'),'icon-class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vehicle['vehicle_type'] === 'motorcycle' ? 'fas fa-motorcycle' : 'fas fa-car'),'icon-bg-class' => 'bg-blue-100','icon-text-class' => 'text-blue-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f216e051c231b98198765acd723fb77)): ?>
<?php $attributes = $__attributesOriginal8f216e051c231b98198765acd723fb77; ?>
<?php unset($__attributesOriginal8f216e051c231b98198765acd723fb77); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f216e051c231b98198765acd723fb77)): ?>
<?php $component = $__componentOriginal8f216e051c231b98198765acd723fb77; ?>
<?php unset($__componentOriginal8f216e051c231b98198765acd723fb77); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Recent Transactions -->
    <div class="bg-white p-6 rounded-xl shadow border border-gray-100">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-dark">Recent Transactions</h3>
            <a href="<?php echo e(route('transactions.index')); ?>" class="text-sm text-primary hover:underline">View All</a>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead>
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider">ID</th>
                        <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider">Tanggal</th>
                        <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider">Total</th>
                        <th class="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider">Status</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $transactions->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-primary">
                            <a href="<?php echo e(route('transactions.show', $transaction->id)); ?>">
                                <?php echo e($transaction->transaction_id); ?>

                            </a>
                        </td>
                        <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-600">
                            <?php echo e($transaction->created_at->format('Y-m-d')); ?>

                        </td>
                        <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-600">
                            Rp <?php echo e(number_format($transaction->total_amount, 0, ',', '.')); ?>

                        </td>
                        <td class="px-4 py-3 whitespace-nowrap">
                            <?php
                                $statusColors = [
                                    'pending' => 'bg-blue-100 text-yellow-800',
                                    'success' => 'bg-green-100 text-green-800',
                                    'failed' => 'bg-red-100 text-red-800',
                                    'expired' => 'bg-yellow-100 text-yellow-800',
                                ];
                                $statusLabels = [
                                    'pending' => 'Tertunda',
                                    'success' => 'Selesai',
                                    'failed' => 'Dibatalkan',
                                    'expired' => 'Dibatalkan',
                                ];
                                $colorClass = $statusColors[$transaction->status] ?? 'bg-gray-200 text-gray-700';
                                $label = $statusLabels[$transaction->status] ?? ucfirst($transaction->status);
                            ?>
                            <span class="px-2 py-1 text-xs rounded-full <?php echo e($colorClass); ?>"><?php echo e($label); ?></span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-4 text-gray-500">Tidak ada transaksi ditemukan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CarbonDevelopment\Test - cobaMQTT\resources\views/dashboard.blade.php ENDPATH**/ ?>